# JMBHUB AUTH + LOGO FIX

This build fixes the frontend Firebase configuration and replaces the old E-shaped favicon/brand mark with the JMB logo across the pages.

## Firebase configuration included
- Project ID: jmb-hub
- Auth domain: jmb-hub.firebaseapp.com

## Before testing login
In Firebase Console → Authentication → Sign-in method:
1. Enable Email/Password.
2. Enable Google.

In Authentication → Settings → Authorized domains, add:
- jmbhost.qzz.io
- www.jmbhost.qzz.io
- jmb-hub.firebaseapp.com

## GitHub Pages
After replacing the site files, wait for GitHub Pages to publish, then hard-refresh the browser (Ctrl+Shift+R).

The Firebase web config is intentionally included in `js/config/firebase-config.js`. Never put Firebase Admin service-account private keys in the website.
